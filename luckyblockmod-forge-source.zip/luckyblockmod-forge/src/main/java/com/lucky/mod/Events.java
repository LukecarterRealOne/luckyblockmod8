package com.lucky.mod;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LuckyBlockMod.MOD_ID)
public class Events {
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        DamageSource src = event.getSource();
        // Aegis Shield: nothing gets through (void / kill still work)
        if (LuckyBlockItem.SHIELDED.contains(player.getUUID()) && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);
            return;
        }
        // summoned allies can never damage any player
        Entity attacker = src.getEntity();
        Entity direct = src.getDirectEntity();
        if ((attacker != null && attacker.getTags().contains("lbm_ally"))
                || (direct != null && direct.getTags().contains("lbm_ally"))) {
            event.setCanceled(true);
        }
    }
}
