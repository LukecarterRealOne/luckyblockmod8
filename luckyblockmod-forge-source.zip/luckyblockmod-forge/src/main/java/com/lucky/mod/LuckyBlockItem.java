package com.lucky.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Lucky Block: right-click casts the selected ability (random by default).
 * Sneak + right-click = Omega Beam. Press G for the ability menu.
 */
public class LuckyBlockItem extends Item {
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1.0f, 0.9f, 0.0f), 2.0f);
    private static final DustParticleOptions GOLD = new DustParticleOptions(new Vector3f(1.0f, 0.65f, 0.0f), 1.4f);
    private static final DustParticleOptions GREEN = new DustParticleOptions(new Vector3f(0.3f, 1.0f, 0.4f), 1.3f);

    public static final Map<UUID, Integer> SELECTED = new HashMap<>();
    public static final Set<UUID> SHIELDED = new HashSet<>();
    private static final Set<Integer> ENDED = new HashSet<>();
    private static final int[] COOLDOWNS = {160, 40, 40, 40, 40, 40, 80, 100, 200, 600, 600, 160, 100, 120, 80, 80, 40, 800};
    private static int beamCounter = 0;

    public LuckyBlockItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);
        if (!(level instanceof ServerLevel sw)) {
            return InteractionResultHolder.success(stack);
        }
        int a = user.isShiftKeyDown() ? 0 : SELECTED.getOrDefault(user.getUUID(), -1);
        if (a < 0 || a >= Abilities.COUNT) {
            a = level.random.nextInt(Abilities.COUNT);
        }
        castAbility(sw, user, a);
        user.getCooldowns().addCooldown(this, COOLDOWNS[a]);
        return InteractionResultHolder.success(stack);
    }

    public void castAbility(ServerLevel sw, Player user, int a) {
        switch (a) {
            case 0 -> omegaBeam(sw, user);
            case 1 -> lightningStorm(sw, user);
            case 2 -> meteorShower(sw, user);
            case 3 -> healingNova(sw, user);
            case 4 -> skyLaunch(sw, user);
            case 5 -> itemRain(sw, user);
            case 6 -> gravityWarp(sw, user);
            case 7 -> summonAllies(sw, user);
            case 8 -> orbitalStrike(sw, user);
            case 9 -> aegisShield(sw, user);
            case 10 -> guardianLegion(sw, user);
            case 11 -> blackHole(sw, user);
            case 12 -> frostNova(sw, user);
            case 13 -> tornado(sw, user);
            case 14 -> dragonBreath(sw, user);
            case 15 -> arrowStorm(sw, user);
            case 16 -> blinkStrike(sw, user);
            default -> overdrive(sw, user);
        }
    }

    /** Called when the player clicks an ability in the G menu. */
    public static void onSelect(ServerPlayer player, int ability, boolean castNow) {
        if (ability < -1 || ability >= Abilities.COUNT) return;
        if (ability < 0) {
            SELECTED.remove(player.getUUID());
        } else {
            SELECTED.put(player.getUUID(), ability);
        }
        String name = ability < 0 ? "Random Roll" : Abilities.NAMES[ability];
        msg(player, "\u00a76Lucky Block ability: \u00a7e\u00a7l" + name);
        if (castNow && ability >= 0 && player.level() instanceof ServerLevel sw) {
            ItemStack held = player.getMainHandItem().getItem() instanceof LuckyBlockItem
                    ? player.getMainHandItem() : player.getOffhandItem();
            if (!(held.getItem() instanceof LuckyBlockItem item)) {
                msg(player, "\u00a7cHold the Lucky Block to cast from the menu");
                return;
            }
            if (player.getCooldowns().isOnCooldown(item)) {
                msg(player, "\u00a7cLucky Block is recharging!");
                return;
            }
            item.castAbility(sw, player, ability);
            player.getCooldowns().addCooldown(item, COOLDOWNS[ability]);
        }
    }

    // ---------------- helpers ----------------
    private static void msg(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    private static boolean gone(ServerLevel sw, Player user) {
        return !user.isAlive() || user.isRemoved() || user.level() != sw;
    }

    private static boolean friend(Entity e, Player user) {
        return e == user || e.getTags().contains("lbm_ally");
    }

    /** Set an entity's velocity and make sure clients see it. */
    private static void launch(Entity e, double x, double y, double z) {
        e.setDeltaMovement(x, y, z);
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    /** Add to an entity's velocity and make sure clients see it. */
    private static void push(Entity e, double x, double y, double z) {
        Vec3 v = e.getDeltaMovement();
        launch(e, v.x + x, v.y + y, v.z + z);
    }

    private record Beam(Vec3 eye, Vec3 dir, double len, Vec3 impact) {}

    private static Beam aim(ServerLevel sw, Player user) {
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Vec3 end = eye.add(dir.scale(96));
        BlockHitResult hit = sw.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double len = miss ? 96 : eye.distanceTo(hit.getLocation());
        return new Beam(eye, dir, len, miss ? end : hit.getLocation());
    }

    private static Vec3[] basis(Vec3 dir) {
        Vec3 up = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = dir.cross(up).normalize();
        Vec3 realUp = right.cross(dir).normalize();
        return new Vec3[]{right, realUp};
    }

    private record Target(Vec3 pos, LivingEntity entity) {}

    /** What the player is looking at: the nearest living entity on the ray, else the block hit (or far point). */
    private static Target pickTarget(ServerLevel sw, Player user, double range) {
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult hit = sw.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double bestT = miss ? range : eye.distanceTo(hit.getLocation());
        LivingEntity best = null;
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(2), x -> x != user)) {
            Vec3 c = e.position().add(0, e.getBbHeight() / 2, 0);
            double t = c.subtract(eye).dot(dir);
            if (t < 0 || t > bestT) continue;
            if (eye.add(dir.scale(t)).distanceTo(c) <= 1.5 + e.getBbWidth() / 2) {
                best = e;
                bestT = t;
            }
        }
        if (best != null) {
            return new Target(best.position().add(0, best.getBbHeight() / 2, 0), best);
        }
        return new Target(miss ? end : hit.getLocation(), null);
    }

    // ---------------- 0: YELLOW OMEGA BEAM ----------------
    // 1.5s charge-up -> 1.8s REAL laser (stretched block-display entities) you can sweep -> huge finale
    private static final double MUZZLE = 3.5;
    private static final String[] BEAM_BLOCKS = {
            "minecraft:yellow_stained_glass", "minecraft:yellow_stained_glass",
            "minecraft:yellow_concrete", "minecraft:white_concrete"};
    private static final double[] BEAM_WIDTHS = {6.0, 3.4, 1.7, 0.8};

    private void omegaBeam(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7l\u26a1 CHARGING OMEGA BEAM... \u26a1");
        final int charge = 30;
        final int fire = 36;
        final int id = ++beamCounter;
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, charge + 5, 4, false, false));
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 0.5f);
        Fx.screen(sw, user.position(), 48, 0f, 0.5f, charge, 0xFFF07A);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> chargeTick(sw, user, tt, charge));
        }
        Scheduler.later(charge + 1, () -> fireStart(sw, user));
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> beamTick(sw, user, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> finale(sw, user, id));
    }

    private void chargeTick(ServerLevel sw, Player user, int t, int total) {
        if (gone(sw, user)) return;
        float p = t / (float) total;
        Vec3 dir = user.getLookAngle();
        Vec3 c = user.getEyePosition().add(dir.scale(MUZZLE)).add(0, -0.3, 0);
        Vec3[] ax = basis(dir);
        double radius = 6.0 * (1 - p) + 0.4;
        int pts = 20;
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts + t * 0.5;
            Vec3 o = ax[0].scale(Math.cos(a) * radius).add(ax[1].scale(Math.sin(a) * radius));
            Fx.burst(sw, GOLD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            if (i % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            }
        }
        DustParticleOptions orb = new DustParticleOptions(new Vector3f(1f, 0.92f, 0.1f), 1f + 3f * p);
        Fx.burst(sw, orb, c.x, c.y, c.z, 6, 0.4, 0.4, 0.4, 0);
        if (t % 4 == 0) {
            Fx.sound(sw, user.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5f, 0.5f + 1.5f * p);
        }
        if (t == total - 4) {
            Fx.screen(sw, user.position(), 48, 0.35f, 1.2f, 6, 0xFFF07A);
        }
    }

    private void fireStart(ServerLevel sw, Player user) {
        if (gone(sw, user)) return;
        msg(user, "\u00a7e\u00a7l\u26a1 YELLOW OMEGA BEAM! \u26a1");
        Vec3 m = user.getEyePosition().add(user.getLookAngle().scale(MUZZLE));
        Fx.sound(sw, user.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, 4f, 0.7f);
        Fx.sound(sw, user.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 3f, 1.4f);
        Fx.burst(sw, ParticleTypes.FLASH, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.SONIC_BOOM, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.screen(sw, user.position(), 96, 1.0f, 4.5f, 44, 0xFFF07A);
    }

    /** SNBT transformation that stretches a unit block into a w x w x len box pointing along q's local +Z. */
    private static String transformSnbt(Quaternionf q, double w, double len) {
        Vector3f tr = new Vector3f((float) (-w / 2), (float) (-w / 2), 0f);
        q.transform(tr);
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[%.5ff,%.5ff,%.5ff,%.5ff],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,%.4ff,%.4ff]}",
                q.x, q.y, q.z, q.w, w, w, len, tr.x, tr.y, tr.z);
    }

    private void beamTick(ServerLevel sw, Player user, int t, int total, int id) {
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3 dir = b.dir();
        Vec3 origin = b.eye().add(dir.scale(MUZZLE)).add(0, -0.3, 0);
        double len = Math.max(0.5, b.len() - MUZZLE);
        double grow = Math.min(1.0, (t + 1) / 4.0);
        if (t >= total - 4) grow = Math.min(grow, (total - t) / 4.0);
        double pulse = 1.0 + 0.06 * Math.sin(t * 1.7);
        Quaternionf q = new Quaternionf().rotationTo(0f, 0f, 1f, (float) dir.x, (float) dir.y, (float) dir.z);

        for (int k = 0; k < BEAM_BLOCKS.length; k++) {
            double w = BEAM_WIDTHS[k] * grow * pulse;
            String tf = transformSnbt(q, w, len);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:4f,"
                                + "brightness:{sky:15,block:15},%s}",
                        origin.x, origin.y, origin.z, BEAM_BLOCKS[k], id, id, k, tf));
            } else {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:1}",
                        id, k, tf));
            }
        }
        if (t > 0) {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, origin.x, origin.y, origin.z));
        }

        Vec3[] ax = basis(dir);
        for (double d = MUZZLE; d <= b.len(); d += 1.2) {
            Vec3 p = b.eye().add(dir.scale(d)).add(0, -0.3, 0);
            int idx = (int) (d / 1.2);
            if (idx % 2 == 0) {
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 3, 2.5, 2.5, 2.5, 0.4);
            }
            if (idx % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 1.5, 1.5, 1.5, 0.05);
            }
            double ang = d * 0.9 + t * 0.9;
            for (int s = 0; s < 2; s++) {
                double a = ang + s * Math.PI;
                double r = 3.6 * grow;
                Vec3 o = ax[0].scale(Math.cos(a) * r).add(ax[1].scale(Math.sin(a) * r));
                Fx.burst(sw, GOLD, p.x + o.x, p.y + o.y, p.z + o.z, 1, 0, 0, 0, 0);
            }
        }

        if (t % 4 == 0) {
            damageAlong(sw, user, b, 70f, 4.5);
        }

        Vec3 im = b.impact();
        Fx.burst(sw, ParticleTypes.FLAME, im.x, im.y + 0.3, im.z, 25, 2.5, 0.8, 2.5, 0.1);
        Fx.burst(sw, ParticleTypes.LAVA, im.x, im.y + 0.3, im.z, 6, 2.5, 0.4, 2.5, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, im.x, im.y + 0.3, im.z, 12, 2.5, 1.0, 2.5, 0.06);
        Fx.burst(sw, YELLOW, im.x, im.y + 0.5, im.z, 25, 3.0, 1.0, 3.0, 0);
        Fx.ring(sw, YELLOW, im.x, im.y + 0.2, im.z, 2 + (t % 10) * 1.0, 40);
        for (double y = 0; y <= 60; y += 2) {
            Fx.burst(sw, YELLOW, im.x, im.y + y, im.z, 4, 0.9, 0.1, 0.9, 0);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, user.blockPosition(), SoundEvents.GENERIC_EXPLODE, 2f, 0.5f);
        }
    }

    private void damageAlong(ServerLevel sw, Player user, Beam b, float dmg, double radius) {
        Vec3 end = b.eye().add(b.dir().scale(b.len()));
        List<LivingEntity> targets = sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(b.eye(), end).inflate(radius + 0.5), e -> !friend(e, user));
        for (LivingEntity e : targets) {
            Vec3 center = e.position().add(0, e.getBbHeight() / 2, 0);
            double t = Mth.clamp(center.subtract(b.eye()).dot(b.dir()), 0, b.len());
            Vec3 closest = b.eye().add(b.dir().scale(t));
            if (closest.distanceTo(center) <= radius) {
                e.hurt(sw.damageSources().indirectMagic(user, user), dmg);
                e.setSecondsOnFire(10);
                push(e, b.dir().x * 0.8, 0.3, b.dir().z * 0.8);
                Fx.burst(sw, ParticleTypes.EXPLOSION, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 1, 0, 0, 0, 0);
            }
        }
    }

    private void finale(ServerLevel sw, Player user, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3 im = b.impact();
        sw.explode(user, im.x, im.y, im.z, 8f, Level.ExplosionInteraction.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, im.x, im.y, im.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, im.x, im.y + 1, im.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, user.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 4f, 0.6f);
        Fx.screen(sw, im, 96, 1.0f, 6.0f, 30, 0xFFF07A);
        damageAlong(sw, user, b, 100f, 6.0);
        for (int k = 0; k < 6; k++) {
            final double r = 2 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, YELLOW, im.x, im.y + 0.3, im.z, r, 64);
                Fx.ring(sw, ParticleTypes.END_ROD, im.x, im.y + 0.6, im.z, r, 32);
            });
        }
    }

    // ---------------- 1: LIGHTNING STORM ----------------
    private void lightningStorm(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lLightning Storm!");
        for (int i = 0; i < 10; i++) {
            double a = sw.random.nextDouble() * Math.PI * 2;
            double r = 4 + sw.random.nextDouble() * 7;
            final Vec3 pos = user.position().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            Scheduler.later(i * 3 + 1, () -> {
                if (gone(sw, user)) return;
                Fx.ring(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
                Fx.sound(sw, user.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 1.8f);
            });
            Scheduler.later(i * 3 + 13, () -> {
                if (gone(sw, user)) return;
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
                if (bolt != null) {
                    bolt.moveTo(pos.x, pos.y, pos.z);
                    sw.addFreshEntity(bolt);
                }
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1, pos.z, 40, 0.6, 1.2, 0.6, 0.4);
                Fx.screen(sw, pos, 64, 0.4f, 1.5f, 8, 0xBFE9FF);
            });
        }
    }

    // ---------------- 2: METEOR SHOWER ----------------
    private void meteorShower(ServerLevel sw, Player user) {
        msg(user, "\u00a7c\u00a7lMeteor Shower!");
        Vec3 target = user.getEyePosition().add(user.getLookAngle().scale(18));
        List<LargeFireball> fireballs = new ArrayList<>();
        Fx.screen(sw, user.position(), 64, 0.3f, 0.8f, 20, 0xFF7A1A);
        for (int i = 0; i < 8; i++) {
            final Vec3 start = target.add((sw.random.nextDouble() - 0.5) * 12, 25 + sw.random.nextDouble() * 8,
                    (sw.random.nextDouble() - 0.5) * 12);
            Scheduler.later(i * 4 + 1, () -> {
                LargeFireball fb = new LargeFireball(sw, user, 0, -1.2, 0, 2);
                fb.setPos(start.x, start.y, start.z);
                sw.addFreshEntity(fb);
                fireballs.add(fb);
                Fx.burst(sw, ParticleTypes.FLAME, start.x, start.y, start.z, 25, 0.6, 0.6, 0.6, 0.1);
                Fx.sound(sw, user.blockPosition(), SoundEvents.BLAZE_SHOOT, 2f, 0.6f);
            });
        }
        trail(sw, fireballs, 100);
    }

    private void trail(ServerLevel sw, List<LargeFireball> fireballs, int remaining) {
        for (LargeFireball fb : new ArrayList<>(fireballs)) {
            if (!fb.isRemoved()) {
                Fx.burst(sw, ParticleTypes.FLAME, fb.getX(), fb.getY(), fb.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.LARGE_SMOKE, fb.getX(), fb.getY(), fb.getZ(), 3, 0.3, 0.3, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.LAVA, fb.getX(), fb.getY(), fb.getZ(), 1, 0.2, 0.2, 0.2, 0);
            }
        }
        if (remaining > 0) {
            Scheduler.later(1, () -> trail(sw, fireballs, remaining - 1));
        }
    }

    // ---------------- 3: HEALING NOVA ----------------
    private void healingNova(ServerLevel sw, Player user) {
        msg(user, "\u00a7a\u00a7lHealing Nova!");
        user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
        user.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 3));
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
        user.setHealth(user.getMaxHealth());
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 2f, 1.2f);
        Fx.screen(sw, user.position(), 32, 0.3f, 0f, 1, 0x66FF99);
        for (int t = 0; t < 20; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.ring(sw, ParticleTypes.HAPPY_VILLAGER, x, y + 0.1, z, 0.5 + tt * 0.4, 36);
                Fx.ring(sw, GREEN, x, y + 0.2, z, 0.5 + tt * 0.4, 24);
                for (int s = 0; s < 2; s++) {
                    double a = tt * 0.7 + s * Math.PI;
                    Fx.burst(sw, GOLD, x + Math.cos(a), y + tt * 0.12, z + Math.sin(a), 2, 0.05, 0.05, 0.05, 0);
                }
                if (tt == 19) {
                    Fx.burst(sw, ParticleTypes.HEART, x, y + 1.5, z, 20, 0.6, 0.6, 0.6, 0.1);
                }
            });
        }
    }

    // ---------------- 4: SKY LAUNCH ----------------
    private void skyLaunch(ServerLevel sw, Player user) {
        msg(user, "\u00a7d\u00a7lSky Launch!");
        push(user, 0, 2.2, 0);
        user.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0));
        Fx.sound(sw, user.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 2f, 1f);
        Fx.screen(sw, user.position(), 48, 0.5f, 2.0f, 8, 0xFFFFFF);
        for (int k = 1; k <= 4; k++) {
            Fx.ring(sw, ParticleTypes.CLOUD, user.getX(), user.getY() + 0.1, user.getZ(), k, 32);
        }
        for (int t = 0; t < 25; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.burst(sw, ParticleTypes.FIREWORK, x, y, z, 6, 0.2, 0.1, 0.2, 0.05);
                Fx.burst(sw, ParticleTypes.CLOUD, x, y, z, 4, 0.3, 0.1, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.FLAME, x, y, z, 3, 0.15, 0.05, 0.15, 0.02);
                if (tt % 5 == 0) {
                    Fx.ring(sw, ParticleTypes.END_ROD, x, y, z, 1 + tt * 0.1, 20);
                }
            });
        }
    }

    // ---------------- 5: ITEM RAIN ----------------
    // Rains RANDOM items from the whole item registry: vanilla AND every installed mod.
    private void itemRain(ServerLevel sw, Player user) {
        List<Item> all = new ArrayList<>();
        for (Item item : ForgeRegistries.ITEMS) {
            if (item != Items.AIR) all.add(item);
        }
        msg(user, "\u00a76\u00a7lITEM RAIN! (" + all.size() + " possible items)");
        final Vec3 base = user.position();
        Fx.sound(sw, user.blockPosition(), SoundEvents.PLAYER_LEVELUP, 2f, 1f);
        Fx.screen(sw, base, 32, 0.35f, 0.6f, 10, 0xFFD84A);
        for (int t = 0; t < 30; t++) {
            Scheduler.later(t + 1, () -> {
                for (double y = 0; y <= 14; y += 1) {
                    Fx.burst(sw, GOLD, base.x, base.y + y, base.z, 2, 0.5, 0, 0.5, 0);
                }
            });
        }
        for (int i = 0; i < 30; i++) {
            Item item = all.get(sw.random.nextInt(all.size()));
            int count = 1 + sw.random.nextInt(Math.max(1, Math.min(item.getMaxStackSize(), 16)));
            ItemStack loot = new ItemStack(item, count);
            final double x = base.x + (sw.random.nextDouble() - 0.5) * 6;
            final double z = base.z + (sw.random.nextDouble() - 0.5) * 6;
            final double y = base.y + 5 + sw.random.nextDouble() * 3;
            Scheduler.later(i * 2 + 2, () -> {
                sw.addFreshEntity(new ItemEntity(sw, x, y, z, loot));
                Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, x, y, z, 10, 0.2, 0.2, 0.2, 0.3);
            });
        }
    }

    // ---------------- 6: GRAVITY WARP ----------------
    private void gravityWarp(ServerLevel sw, Player user) {
        msg(user, "\u00a75\u00a7lGRAVITY WARP!");
        Target tg = pickTarget(sw, user, 48);
        final Vec3 c = tg.pos();
        final double r = 7;
        final List<LivingEntity> victims = sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r),
                e -> !friend(e, user) && e.distanceToSqr(c) <= r * r);
        final DustParticleOptions purple = new DustParticleOptions(new Vector3f(0.6f, 0.2f, 1.0f), 1.6f);

        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_ACTIVATE, 3f, 0.6f);
        Fx.screen(sw, c, 64, 0.3f, 1.0f, 10, 0xAA66FF);
        for (LivingEntity e : victims) {
            e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 3, false, true));
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 80, 0, false, false));
        }
        for (int t = 0; t < 60; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                double rise = (tt % 30) * 0.5;
                Fx.ring(sw, purple, c.x, c.y + rise, c.z, r, 40);
                Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, c.x, c.y + rise, c.z, r * 0.6, 20);
                for (LivingEntity e : victims) {
                    if (e.isAlive()) {
                        Fx.burst(sw, ParticleTypes.PORTAL, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(),
                                6, 0.4, 0.6, 0.4, 0.3);
                    }
                }
                if (tt % 10 == 0) {
                    Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_AMBIENT, 2f, 0.5f);
                }
            });
        }
        Scheduler.later(62, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.removeEffect(MobEffects.LEVITATION);
                launch(e, 0, -3.5, 0);
                e.hurt(sw.damageSources().magic(), 12f);
            }
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 3f, 0.7f);
            Fx.screen(sw, c, 64, 0.4f, 2.5f, 12, 0xAA66FF);
            for (int k = 0; k < 6; k++) {
                final double rr = 2 + k * 2.5;
                Scheduler.later(k + 1, () -> Fx.ring(sw, purple, c.x, c.y, c.z, rr, 48));
            }
        });
    }

    // ---------------- 7: ALLY SUMMON (instant, works with modded mobs) ----------------
    private Mob spawnAlly(ServerLevel sw, Player user, EntityType<?> type, Vec3 pos, boolean guardian) {
        Entity e = null;
        try {
            e = type.create(sw);
        } catch (Exception ignored) {
        }
        if (!(e instanceof Mob mob)) return null;
        mob.moveTo(pos.x, pos.y, pos.z, user.getYRot(), 0f);
        try {
            mob.finalizeSpawn(sw, sw.getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
        } catch (Exception ignored) {
        }
        if (mob instanceof IronGolem golem) golem.setPlayerCreated(true);
        mob.setPersistenceRequired();
        mob.addTag("lbm_ally");
        int dur = guardian ? 2500 : 1300;
        int amp = guardian ? 2 : 1;
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, amp));
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, amp));
        mob.addEffect(new MobEffectInstance(MobEffects.REGENERATION, dur, 1));
        mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, dur, 0, false, false));
        if (guardian) {
            mob.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, dur, 4));
            mob.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, dur, 0));
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 1));
            mob.setCustomName(Component.literal("\u00a7b\u00a7lGuardian"));
            mob.setCustomNameVisible(true);
        }
        mob.setTarget(null);   // friendly from the very first tick
        sw.addFreshEntity(mob);

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
        if (bolt != null) {
            bolt.moveTo(pos.x, pos.y, pos.z);
            bolt.setVisualOnly(true);
            sw.addFreshEntity(bolt);
        }
        Fx.ring(sw, ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
        Fx.burst(sw, ParticleTypes.END_ROD, pos.x, pos.y + 1, pos.z, 30, 0.3, 1.2, 0.3, 0.1);
        Fx.burst(sw, ParticleTypes.PORTAL, pos.x, pos.y + 1, pos.z, 40, 0.6, 1.0, 0.6, 0.5);
        return mob;
    }

    private void summonAllies(ServerLevel sw, Player user) {
        List<EntityType<?>> modded = new ArrayList<>();
        for (ResourceLocation id : ForgeRegistries.ENTITY_TYPES.getKeys()) {
            String ns = id.getNamespace();
            if (ns.equals("minecraft") || ns.equals(LuckyBlockMod.MOD_ID)) continue;
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(id);
            if (type == null || type.getCategory() == MobCategory.MISC || !type.canSummon()) continue;
            modded.add(type);
        }
        List<EntityType<?>> fallback = List.<EntityType<?>>of(EntityType.IRON_GOLEM, EntityType.WOLF,
                EntityType.WOLF, EntityType.VINDICATOR, EntityType.IRON_GOLEM);

        msg(user, modded.isEmpty()
                ? "\u00a7b\u00a7lAllies Summoned!"
                : "\u00a7b\u00a7lModded Allies Summoned! (" + modded.size() + " mob types found)");

        final int total = 5;
        final List<Mob> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        StringBuilder names = new StringBuilder();
        // everything spawns in the SAME tick
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3 pos = user.position().add(Math.cos(a) * 3.5, 0, Math.sin(a) * 3.5);
            Mob mob = null;
            for (int attempt = 0; attempt < 6 && mob == null; attempt++) {
                EntityType<?> type = (!modded.isEmpty() && i < 4 && attempt < 5)
                        ? modded.get(sw.random.nextInt(modded.size()))
                        : fallback.get(i % fallback.size());
                mob = spawnAlly(sw, user, type, pos, false);
            }
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUUID());
                if (names.length() > 0) names.append(", ");
                names.append(mob.getType().getDescription().getString());
            }
        }
        user.sendSystemMessage(Component.literal("\u00a7bSummoned: " + names));
        Fx.sound(sw, user.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 3f, 1f);
        allyTick(sw, user, allies, ids, 1200, 100.0);
    }

    // ---------------- 10: GUARDIAN LEGION ----------------
    private void guardianLegion(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lGUARDIAN LEGION!");
        final List<Mob> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        int total = 6;
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3 pos = user.position().add(Math.cos(a) * 4.5, 0, Math.sin(a) * 4.5);
            Mob mob = spawnAlly(sw, user, EntityType.IRON_GOLEM, pos, true);
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUUID());
            }
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 3f, 0.7f);
        Fx.screen(sw, user.position(), 48, 0.4f, 2.0f, 12, 0x88DDFF);
        for (int k = 0; k < 5; k++) {
            final double r = 2 + k * 2.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 0.2, user.getZ(), r, 40));
        }
        allyTick(sw, user, allies, ids, 2400, 36.0);
    }

    private void allyTick(ServerLevel sw, Player user, List<Mob> allies, Set<UUID> ids, int remaining, double followSq) {
        boolean any = false;
        LivingEntity attacker = user.getLastHurtByMob();
        for (Mob a : allies) {
            if (a.isRemoved() || !a.isAlive()) continue;
            any = true;
            if (remaining <= 0) {
                Fx.burst(sw, ParticleTypes.POOF, a.getX(), a.getY() + 1, a.getZ(), 30, 0.5, 0.8, 0.5, 0.05);
                a.discard();
                continue;
            }
            LivingEntity tgt = a.getTarget();
            if (tgt instanceof Player || (tgt != null && ids.contains(tgt.getUUID()))) {
                a.setTarget(null);
            }
            // protect the owner: go after whatever hurt them
            if (attacker != null && attacker.isAlive() && !(attacker instanceof Player)
                    && !ids.contains(attacker.getUUID())) {
                a.setTarget(attacker);
            }
            LivingEntity cur = a.getTarget();
            if ((cur == null || !cur.isAlive()) && remaining % 5 == 0) {
                Mob best = null;
                double bd = Double.MAX_VALUE;
                for (Mob f : sw.getEntitiesOfClass(Mob.class, a.getBoundingBox().inflate(20),
                        m -> m instanceof Enemy && m.isAlive() && !ids.contains(m.getUUID()))) {
                    double d = a.distanceToSqr(f);
                    if (d < bd) {
                        bd = d;
                        best = f;
                    }
                }
                if (best != null) {
                    a.setTarget(best);
                } else if (a.distanceToSqr(user) > followSq) {
                    a.getNavigation().moveTo(user, 1.3);
                }
            }
        }
        if (any && remaining > 0) {
            Scheduler.later(1, () -> allyTick(sw, user, allies, ids, remaining - 1, followSq));
        }
    }

    // ---------------- 8: ORBITAL STRIKE ----------------
    private static final String[] ORB_BLOCKS = {
            "minecraft:cyan_stained_glass", "minecraft:light_blue_stained_glass", "minecraft:white_concrete"};
    private static final double[] ORB_WIDTHS = {11.0, 6.5, 3.0};

    private static String verticalBeamSnbt(double w, double h) {
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,0f,%.4ff]}",
                w, h, w, -w / 2, -w / 2);
    }

    private void orbitalStrike(ServerLevel sw, Player user) {
        Target tg = pickTarget(sw, user, 128);
        final Vec3 c = tg.pos();
        final int charge = 50;
        final int fire = 50;
        final int id = ++beamCounter;
        final BlockPos bp = BlockPos.containing(c.x, c.y, c.z);
        final DustParticleOptions cyan = new DustParticleOptions(new Vector3f(0.3f, 0.9f, 1.0f), 2.0f);

        msg(user, "\u00a7b\u00a7lORBITAL STRIKE LOCKED ON!");
        Fx.sound(sw, bp, SoundEvents.BEACON_ACTIVATE, 4f, 0.5f);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                float p = tt / (float) charge;
                double radius = 12 * (1 - p) + 1;
                Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, radius, 40);
                Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 12, 40);
                Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.3, c.z, 4, 16);
                for (double y = 0; y <= 80; y += 3) {
                    Fx.burst(sw, ParticleTypes.END_ROD, c.x, c.y + y, c.z, 1, 0.1, 0, 0.1, 0);
                }
                if (tt % 5 == 0) {
                    Fx.sound(sw, bp, SoundEvents.EXPERIENCE_ORB_PICKUP, 3f, 0.5f + 1.5f * p);
                }
                if (tt == charge - 5) {
                    Fx.screen(sw, c, 200, 0.4f, 1.5f, 6, 0xBFEFFF);
                }
            });
        }
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> orbitalTick(sw, user, c, cyan, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> orbitalFinale(sw, user, c, cyan, id));
    }

    private void orbitalTick(ServerLevel sw, Player user, Vec3 c, DustParticleOptions cyan, int t, int total, int id) {
        double grow = Math.min(1.0, (t + 1) / 2.0);
        if (t >= total - 6) grow = Math.min(grow, (total - t) / 6.0);
        double pulse = 1.0 + 0.05 * Math.sin(t * 1.9);

        for (int k = 0; k < ORB_BLOCKS.length; k++) {
            double w = ORB_WIDTHS[k] * grow * pulse;
            String tf = verticalBeamSnbt(w, 400);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:8f,"
                                + "brightness:{sky:15,block:15},%s}",
                        c.x, c.y - 2, c.z, ORB_BLOCKS[k], id, id, k, tf));
            } else if (t % 2 == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:2}",
                        id, k, tf));
            }
        }
        if (t == 0) {
            BlockPos bp = BlockPos.containing(c.x, c.y, c.z);
            Fx.sound(sw, bp, SoundEvents.WARDEN_SONIC_BOOM, 6f, 0.5f);
            Fx.sound(sw, bp, SoundEvents.LIGHTNING_BOLT_THUNDER, 6f, 0.8f);
            Fx.screen(sw, c, 250, 1.0f, 7.0f, 55, 0xBFEFFF);
        }
        if (t % 3 == 0) {
            AABB zone = new AABB(c.x - 9, c.y - 6, c.z - 9, c.x + 9, c.y + 60, c.z + 9);
            for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, zone, e -> !friend(e, user))) {
                double dx = e.getX() - c.x;
                double dz = e.getZ() - c.z;
                if (dx * dx + dz * dz <= 81) {
                    e.hurt(sw.damageSources().indirectMagic(user, user), 60f);
                    e.setSecondsOnFire(10);
                    push(e, 0, 0.6, 0);
                }
            }
        }
        Fx.burst(sw, ParticleTypes.FLAME, c.x, c.y + 0.3, c.z, 30, 4.0, 1.0, 4.0, 0.12);
        Fx.burst(sw, ParticleTypes.LAVA, c.x, c.y + 0.3, c.z, 8, 4.0, 0.5, 4.0, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.3, c.z, 14, 4.0, 1.5, 4.0, 0.06);
        Fx.burst(sw, cyan, c.x, c.y + 0.5, c.z, 30, 4.5, 1.2, 4.5, 0);
        Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 3 + (t % 12) * 1.2, 48);
        for (double y = 0; y <= 40; y += 3) {
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, c.x, c.y + y, c.z, 3, 3.5, 1.0, 3.5, 0.4);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 4f, 0.5f);
        }
    }

    private void orbitalFinale(ServerLevel sw, Player user, Vec3 c, DustParticleOptions cyan, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.explode(user, c.x, c.y, c.z, 10f, Level.ExplosionInteraction.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.LIGHTNING_BOLT_THUNDER, 6f, 0.5f);
        Fx.screen(sw, c, 250, 1.0f, 8.0f, 35, 0xBFEFFF);
        AABB zone = new AABB(c.x - 12, c.y - 8, c.z - 12, c.x + 12, c.y + 20, c.z + 12);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, zone, e -> !friend(e, user))) {
            if (e.distanceToSqr(c) <= 144) {
                e.hurt(sw.damageSources().indirectMagic(user, user), 100f);
                e.setSecondsOnFire(10);
            }
        }
        for (int k = 0; k < 8; k++) {
            final double r = 3 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, cyan, c.x, c.y + 0.3, c.z, r, 72);
                Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.6, c.z, r, 36);
            });
        }
    }

    // ---------------- 9: AEGIS SHIELD ----------------
    // 20s force-field: no damage gets through, projectiles are reflected back, hostile mobs get blasted away.
    private void aegisShield(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lAEGIS SHIELD ACTIVE!");
        final int id = ++beamCounter;
        final int total = 400;
        SHIELDED.add(user.getUUID());
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 1.4f);
        Fx.screen(sw, user.position(), 32, 0.4f, 1.0f, 8, 0x88DDFF);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> shieldTick(sw, user, tt, total, id));
        }
        Scheduler.later(total + 2, () -> shieldEnd(sw, user, id));
    }

    private void shieldTick(ServerLevel sw, Player user, int t, int total, int id) {
        if (ENDED.contains(id)) return;
        if (gone(sw, user)) {
            shieldEnd(sw, user, id);
            return;
        }
        final DustParticleOptions blue = new DustParticleOptions(new Vector3f(0.4f, 0.85f, 1.0f), 1.5f);
        Vec3 c = user.position().add(0, 1.0, 0);
        if (t == 0) {
            Fx.cmd(sw, String.format(Locale.ROOT,
                    "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:light_blue_stained_glass\"},"
                            + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,brightness:{sky:15,block:15},"
                            + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                            + "scale:[10f,10f,10f],translation:[-5f,-4f,-5f]}}",
                    user.getX(), user.getY(), user.getZ(), id));
        } else {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, user.getX(), user.getY(), user.getZ()));
        }
        for (int i = 0; i < 28; i++) {
            double y = 1 - 2 * (i + 0.5) / 28;
            double rr = Math.sqrt(1 - y * y);
            double a = i * 2.399963 + t * 0.08;
            Fx.burst(sw, blue, c.x + Math.cos(a) * rr * 5.2, c.y + y * 5.2, c.z + Math.sin(a) * rr * 5.2, 1, 0, 0, 0, 0);
            if (i % 4 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, c.x + Math.cos(a) * rr * 5.2, c.y + y * 5.2, c.z + Math.sin(a) * rr * 5.2, 1, 0, 0, 0, 0);
            }
        }
        user.clearFire();
        // deflect every projectile that gets close (arrows, fireballs, tridents, mod projectiles...)
        for (Projectile p : sw.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(7),
                p -> p.getOwner() != user && !p.getTags().contains("lbm_ally"))) {
            if (p.position().distanceTo(c) > 6.5) continue;
            Vec3 away = p.position().subtract(c);
            if (away.lengthSqr() < 0.01) away = new Vec3(0, 1, 0);
            away = away.normalize();
            double speed = Math.max(1.5, p.getDeltaMovement().length() * 1.2);
            launch(p, away.x * speed, away.y * speed + 0.05, away.z * speed);
            p.setOwner(user);
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY(), p.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
            Fx.sound(sw, p.blockPosition(), SoundEvents.SHIELD_BLOCK, 1.5f, 1.2f);
        }
        // blast hostile mobs back
        if (t % 2 == 0) {
            for (Mob m : sw.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(6),
                    m -> m instanceof Enemy && !m.getTags().contains("lbm_ally"))) {
                Vec3 away = m.position().subtract(user.position());
                away = new Vec3(away.x, 0, away.z);
                if (away.lengthSqr() < 0.01) away = new Vec3(1, 0, 0);
                away = away.normalize().scale(1.3);
                push(m, away.x, 0.35, away.z);
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + 1, m.getZ(), 6, 0.3, 0.5, 0.3, 0.2);
            }
        }
        if (t == total - 40) {
            msg(user, "\u00a7c\u00a7lShield ending soon...");
        }
    }

    private void shieldEnd(ServerLevel sw, Player user, int id) {
        if (!ENDED.add(id)) return;
        SHIELDED.remove(user.getUUID());
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 3f, 0.8f);
        Fx.burst(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 80, 3, 2, 3, 0.2);
    }

    // ---------------- 11: BLACK HOLE ----------------
    private void blackHole(ServerLevel sw, Player user) {
        msg(user, "\u00a78\u00a7lBLACK HOLE!");
        Target tg = pickTarget(sw, user, 60);
        final Vec3 c = tg.pos().add(0, 1.5, 0);
        final int id = ++beamCounter;
        final int total = 120;
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_ACTIVATE, 4f, 0.5f);
        Fx.cmd(sw, String.format(Locale.ROOT,
                "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:black_concrete\"},"
                        + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,"
                        + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[3f,3f,3f],translation:[-1.5f,-1.5f,-1.5f]}}",
                c.x, c.y, c.z, id));
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> holeTick(sw, user, c, tt));
        }
        Scheduler.later(total + 1, () -> holeEnd(sw, user, c, id));
    }

    private void holeTick(ServerLevel sw, Player user, Vec3 c, int t) {
        final DustParticleOptions violet = new DustParticleOptions(new Vector3f(0.5f, 0.1f, 0.9f), 1.8f);
        for (int ring = 0; ring < 4; ring++) {
            double r = 3 + ring * 2.2;
            for (int i = 0; i < 14; i++) {
                double a = Math.PI * 2 * i / 14 + t * (0.45 - ring * 0.07);
                Fx.burst(sw, violet, c.x + Math.cos(a) * r, c.y + Math.sin(a * 2 + t * 0.1) * 0.3, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
        Fx.burst(sw, ParticleTypes.PORTAL, c.x, c.y, c.z, 20, 4, 4, 4, 0.8);
        Fx.burst(sw, ParticleTypes.SQUID_INK, c.x, c.y, c.z, 6, 1.5, 1.5, 1.5, 0.05);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(16), e -> !friend(e, user))) {
            Vec3 mid = e.position().add(0, e.getBbHeight() / 2, 0);
            Vec3 to = c.subtract(mid);
            double d = to.length();
            if (d < 0.5) continue;
            Vec3 pull = to.normalize().scale(Math.min(0.9, 6.0 / (d + 2)));
            Vec3 v = e.getDeltaMovement().scale(0.5).add(pull);
            launch(e, v.x, v.y, v.z);
            e.fallDistance = 0;
            if (d < 3 && t % 10 == 0) {
                e.hurt(sw.damageSources().magic(), 8f);
            }
        }
        if (t % 10 == 0) {
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_AMBIENT, 3f, 0.5f);
            Fx.screen(sw, c, 40, 0f, 0.8f, 10, 0x7733CC);
        }
    }

    private void holeEnd(ServerLevel sw, Player user, Vec3 c, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.explode(user, c.x, c.y, c.z, 6f, Level.ExplosionInteraction.NONE);
        Fx.burst(sw, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 4f, 0.5f);
        Fx.screen(sw, c, 80, 1.0f, 6.0f, 25, 0xAA66FF);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(16), e -> !friend(e, user))) {
            Vec3 away = e.position().subtract(c);
            away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
            launch(e, away.x * 2.5, 0.8, away.z * 2.5);
            e.hurt(sw.damageSources().magic(), 40f);
        }
        final DustParticleOptions violet = new DustParticleOptions(new Vector3f(0.5f, 0.1f, 0.9f), 2.0f);
        for (int k = 0; k < 6; k++) {
            final double r = 2 + k * 3;
            Scheduler.later(k + 1, () -> Fx.ring(sw, violet, c.x, c.y, c.z, r, 56));
        }
    }

    // ---------------- 12: FROST NOVA ----------------
    private void frostNova(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lFROST NOVA!");
        final Vec3 c = user.position();
        final double radius = 14;
        final List<LivingEntity> victims = sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius),
                e -> !friend(e, user) && e.distanceToSqr(c) <= radius * radius);
        final DustParticleOptions ice = new DustParticleOptions(new Vector3f(0.6f, 0.9f, 1.0f), 1.8f);
        Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 3f, 0.6f);
        Fx.screen(sw, c, 48, 0.5f, 1.5f, 10, 0xBFEFFF);
        for (LivingEntity e : victims) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 6));
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            e.setTicksFrozen(300);
        }
        for (int t = 0; t < 14; t++) {
            final double r = (t + 1) * 1.0;
            Scheduler.later(t + 1, () -> {
                Fx.ring(sw, ice, c.x, c.y + 0.3, c.z, r, 56);
                Fx.ring(sw, ParticleTypes.SNOWFLAKE, c.x, c.y + 0.6, c.z, r, 40);
            });
        }
        for (int t = 0; t < 45; t++) {
            Scheduler.later(t * 2 + 2, () -> {
                for (LivingEntity e : victims) {
                    if (e.isAlive()) {
                        Fx.burst(sw, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 8, 0.5, 0.7, 0.5, 0.02);
                    }
                }
            });
        }
        Scheduler.later(92, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.hurt(sw.damageSources().magic(), 30f);
                Fx.burst(sw, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 60, 0.6, 0.8, 0.6, 0.3);
                Fx.burst(sw, ice, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 20, 0.6, 0.8, 0.6, 0);
            }
            Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 4f, 1.2f);
        });
    }

    // ---------------- 13: TORNADO ----------------
    private void tornado(ServerLevel sw, Player user) {
        msg(user, "\u00a77\u00a7lTORNADO!");
        Target tg = pickTarget(sw, user, 50);
        final Vec3 c = tg.pos();
        final int total = 140;
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.PHANTOM_FLAP, 4f, 0.5f);
        final DustParticleOptions gray = new DustParticleOptions(new Vector3f(0.8f, 0.8f, 0.85f), 1.8f);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                for (int h = 0; h <= 16; h++) {
                    double r = 1 + h * 0.35;
                    for (int s = 0; s < 3; s++) {
                        double a = tt * 0.5 + h * 0.6 + s * (Math.PI * 2 / 3);
                        double px = c.x + Math.cos(a) * r;
                        double py = c.y + h * 0.9;
                        double pz = c.z + Math.sin(a) * r;
                        if (tt % 2 == 0) {
                            Fx.burst(sw, ParticleTypes.CLOUD, px, py, pz, 1, 0.05, 0.05, 0.05, 0.01);
                        } else {
                            Fx.burst(sw, gray, px, py, pz, 1, 0.05, 0.05, 0.05, 0.01);
                        }
                    }
                }
                for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(7, 18, 7),
                        e -> !friend(e, user))) {
                    double dx = e.getX() - c.x;
                    double dz = e.getZ() - c.z;
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 7) continue;
                    double len = Math.max(0.5, d);
                    double tx = -dz / len * 0.55;
                    double tz = dx / len * 0.55;
                    launch(e, tx - dx / len * 0.1, 0.2, tz - dz / len * 0.1);
                    e.fallDistance = 0;
                    if (tt % 10 == 0) {
                        e.hurt(sw.damageSources().magic(), 4f);
                    }
                }
                if (tt % 20 == 0) {
                    Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.PHANTOM_FLAP, 3f, 0.6f);
                    Fx.screen(sw, c, 40, 0f, 0.7f, 20, 0xDDDDDD);
                }
            });
        }
    }

    // ---------------- 14: DRAGON BREATH ----------------
    private void dragonBreath(ServerLevel sw, Player user) {
        msg(user, "\u00a76\u00a7lDRAGON BREATH!");
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, 3f, 0.8f);
        Fx.screen(sw, user.position(), 48, 0.2f, 1.2f, 40, 0xFF7A1A);
        for (int t = 0; t < 40; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> breathTick(sw, user, tt));
        }
    }

    private void breathTick(ServerLevel sw, Player user, int t) {
        if (gone(sw, user)) return;
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        for (double d = 1.5; d <= 22; d += 1.0) {
            Vec3 p = eye.add(dir.scale(d)).add(0, -0.3, 0);
            double spread = 0.3 + d * 0.28;
            Fx.burst(sw, ParticleTypes.FLAME, p.x, p.y, p.z, 5, spread * 0.6, spread * 0.6, spread * 0.6, 0.02);
            Fx.burst(sw, ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 2, spread * 0.5, spread * 0.5, spread * 0.5, 0.02);
            if (((int) d) % 3 == 0) {
                Fx.burst(sw, ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 1, spread * 0.5, spread * 0.5, spread * 0.5, 0.02);
            }
        }
        if (t % 4 == 0) {
            Vec3 end = eye.add(dir.scale(22));
            for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(6), e -> !friend(e, user))) {
                Vec3 to = e.position().add(0, e.getBbHeight() / 2, 0).subtract(eye);
                double dist = to.length();
                if (dist > 22 || dist < 0.1) continue;
                if (to.normalize().dot(dir) < 0.88) continue;
                e.hurt(sw.damageSources().magic(), 14f);
                e.setSecondsOnFire(8);
            }
            Fx.sound(sw, user.blockPosition(), SoundEvents.BLAZE_SHOOT, 2f, 0.5f);
        }
    }

    // ---------------- 15: ARROW STORM ----------------
    private void arrowStorm(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7lARROW STORM!");
        Target tg = pickTarget(sw, user, 80);
        final Vec3 c = tg.pos();
        final DustParticleOptions red = new DustParticleOptions(new Vector3f(1.0f, 0.2f, 0.2f), 1.6f);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.ARROW_SHOOT, 3f, 0.6f);
        for (int t = 0; t < 45; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (tt % 3 == 0) {
                    Fx.ring(sw, red, c.x, c.y + 0.3, c.z, 9, 40);
                }
                for (int k = 0; k < 3; k++) {
                    var arrow = EntityType.ARROW.create(sw);
                    if (arrow == null) continue;
                    double ox = (sw.random.nextDouble() - 0.5) * 18;
                    double oz = (sw.random.nextDouble() - 0.5) * 18;
                    arrow.setPos(c.x + ox, c.y + 30 + sw.random.nextDouble() * 10, c.z + oz);
                    arrow.setDeltaMovement((sw.random.nextDouble() - 0.5) * 0.2, -3.0, (sw.random.nextDouble() - 0.5) * 0.2);
                    arrow.setOwner(user);
                    arrow.setCritArrow(true);
                    arrow.setBaseDamage(4.0);
                    arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
                    sw.addFreshEntity(arrow);
                }
            });
        }
    }

    // ---------------- 16: BLINK STRIKE ----------------
    private void blinkStrike(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7lBLINK STRIKE!");
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Target tg = pickTarget(sw, user, 80);
        double dist = eye.distanceTo(tg.pos());
        Vec3 p = eye.add(dir.scale(Math.max(1.0, dist - 2.0)));
        Vec3 from = user.position();
        final DustParticleOptions trail = new DustParticleOptions(new Vector3f(1.0f, 0.9f, 0.0f), 1.8f);
        for (double d = 0; d <= dist; d += 1.0) {
            Vec3 q = eye.add(dir.scale(d));
            Fx.burst(sw, trail, q.x, q.y - 0.5, q.z, 3, 0.2, 0.2, 0.2, 0);
            Fx.burst(sw, ParticleTypes.END_ROD, q.x, q.y - 0.5, q.z, 1, 0.1, 0.1, 0.1, 0.02);
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 1f);
        if (user instanceof ServerPlayer sp) {
            sp.teleportTo(p.x, p.y - 1.0, p.z);
        } else {
            user.moveTo(p.x, p.y - 1.0, p.z);
        }
        final Vec3 to = new Vec3(p.x, p.y - 1.0, p.z);

        for (Vec3 pos : new Vec3[]{from, to}) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
                bolt.moveTo(pos.x, pos.y, pos.z);
                bolt.setVisualOnly(true);
                sw.addFreshEntity(bolt);
            }
        }
        Fx.sound(sw, BlockPos.containing(to.x, to.y, to.z), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.7f);
        Fx.screen(sw, to, 48, 0.8f, 3.0f, 12, 0xFFF07A);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(to, to).inflate(6), e -> !friend(e, user))) {
            if (e.distanceToSqr(to) > 36) continue;
            e.hurt(sw.damageSources().indirectMagic(user, user), 30f);
            Vec3 away = e.position().subtract(to);
            away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
            launch(e, away.x * 1.5, 0.6, away.z * 1.5);
        }
        for (int k = 0; k < 4; k++) {
            final double r = 1.5 + k * 1.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, trail, to.x, to.y + 0.3, to.z, r, 36));
        }
    }

    // ---------------- 17: OVERDRIVE ----------------
    private void overdrive(ServerLevel sw, Player user) {
        msg(user, "\u00a7c\u00a7lOVERDRIVE!");
        int dur = 600;
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 2));
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, 2));
        user.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, dur, 2));
        user.addEffect(new MobEffectInstance(MobEffects.JUMP, dur, 2));
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 1));
        user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, dur, 1));
        user.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, dur, 0));
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, 2f, 1.3f);
        Fx.screen(sw, user.position(), 32, 0.6f, 2.5f, 12, 0xFF5522);
        for (int k = 0; k < 5; k++) {
            final double r = 1 + k * 1.5;
            Scheduler.later(k + 1, () -> {
                Fx.ring(sw, ParticleTypes.FLAME, user.getX(), user.getY() + 0.2, user.getZ(), r, 36);
                Fx.ring(sw, GOLD, user.getX(), user.getY() + 0.4, user.getZ(), r, 36);
            });
        }
        for (int t = 0; t < 300; t++) {
            final int tt = t;
            Scheduler.later(t * 2 + 1, () -> {
                if (gone(sw, user)) return;
                double a = tt * 0.6;
                double x = user.getX();
                double y = user.getY() + 0.1 + (tt % 10) * 0.2;
                double z = user.getZ();
                Fx.burst(sw, ParticleTypes.FLAME, x + Math.cos(a) * 0.9, y, z + Math.sin(a) * 0.9, 2, 0.05, 0.05, 0.05, 0.02);
                Fx.burst(sw, GOLD, x + Math.cos(a + Math.PI) * 0.9, y, z + Math.sin(a + Math.PI) * 0.9, 1, 0, 0, 0, 0);
            });
        }
    }
}
