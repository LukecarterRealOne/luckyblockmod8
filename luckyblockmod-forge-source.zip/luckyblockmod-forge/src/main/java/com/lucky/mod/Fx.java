package com.lucky.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

public class Fx {
    /** Particles visible from far away (normal particle spawning only reaches ~32 blocks). */
    public static void burst(ServerLevel sw, ParticleOptions e, double x, double y, double z,
                             int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer p : sw.players()) {
            if (p.distanceToSqr(x, y, z) < 160 * 160) {
                sw.sendParticles(p, e, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    public static void ring(ServerLevel sw, ParticleOptions e, double cx, double cy, double cz, double r, int pts) {
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts;
            burst(sw, e, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    public static void sound(ServerLevel sw, BlockPos pos, SoundEvent s, float vol, float pitch) {
        sw.playSound(null, pos, s, SoundSource.PLAYERS, vol, pitch);
    }

    /** Screen flash + camera shake for nearby players. */
    public static void screen(ServerLevel sw, Vec3 pos, double radius, float flash, float shake, int duration, int color) {
        for (ServerPlayer p : sw.players()) {
            if (p.distanceToSqr(pos) < radius * radius) {
                LuckyBlockMod.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                        new FxPacket(flash, shake, duration, color));
            }
        }
    }

    /** Run a command silently as the server (spawns/updates the laser display entities). */
    public static void cmd(ServerLevel sw, String command) {
        try {
            MinecraftServer server = sw.getServer();
            server.getCommands().getDispatcher().execute(command,
                    server.createCommandSourceStack().withLevel(sw).withSuppressedOutput());
        } catch (Exception ignored) {
            // e.g. "no entity found" during cleanup - harmless
        }
    }
}
