package com.lucky.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Lucky Block ability menu (press G). */
public class AbilityScreen extends Screen {
    private static boolean castNow = false;

    public AbilityScreen() {
        super(Component.literal("Lucky Block Abilities"));
    }

    private static Component modeText() {
        return Component.literal(castNow ? "Click mode: CAST NOW (hold Lucky Block)" : "Click mode: SELECT (then right-click)");
    }

    @Override
    protected void init() {
        int cols = 3;
        int bw = 130;
        int bh = 20;
        int gap = 6;
        int total = Abilities.NAMES.length;
        int rows = (total + cols - 1) / cols;
        int startX = this.width / 2 - (cols * bw + (cols - 1) * gap) / 2;
        int startY = 44;
        for (int i = 0; i < total; i++) {
            final int id = i;
            int x = startX + (i % cols) * (bw + gap);
            int y = startY + (i / cols) * (bh + gap);
            this.addRenderableWidget(Button.builder(Component.literal(Abilities.NAMES[i]), b -> choose(id))
                    .bounds(x, y, bw, bh).build());
        }
        int by = startY + rows * (bh + gap) + 8;
        this.addRenderableWidget(Button.builder(Component.literal("Random Roll"), b -> choose(-1))
                .bounds(startX, by, bw, bh).build());
        this.addRenderableWidget(Button.builder(modeText(), b -> {
            castNow = !castNow;
            b.setMessage(modeText());
        }).bounds(startX + bw + gap, by, bw * 2 + gap, bh).build());
    }

    private void choose(int id) {
        LuckyBlockMod.CHANNEL.sendToServer(new SelectPacket(id, castNow ? 1 : 0));
        this.onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, 14, 0xFFFFFF);
        g.drawCenteredString(this.font,
                Component.literal("Pick an ability, then right-click with the Lucky Block (sneak + right-click = Omega Beam)"),
                this.width / 2, 28, 0xFFE066);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
